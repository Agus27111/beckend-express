export default interface UserType {
  user_id: string
  email: string
  nama: string
  password: string
  confirmPassword?: string
  role: string
}
