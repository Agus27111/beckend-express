import "bootstrap/dist/css/bootstrap.min.css";
import RoutePage from "./components/RoutePage";

function App() {
  return (
    <div>
      <RoutePage />
    </div>
  );
}

export default App;
