import React from "react";

function NoPage() {
  return (
    <div
      className="border d-flex align-items-center justify-content-center"
      style={{ height: "100vh" }}
    >
      <h1>404 Page Not Found</h1>
    </div>
  );
}

export default NoPage;
