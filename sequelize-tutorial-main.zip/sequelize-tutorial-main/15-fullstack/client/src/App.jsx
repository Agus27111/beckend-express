import "bootstrap/dist/css/bootstrap.min.css";
import RoutePage from "./features/RoutePage";

function App() {
  return (
    <div>
      <RoutePage />
    </div>
  );
}

export default App;
