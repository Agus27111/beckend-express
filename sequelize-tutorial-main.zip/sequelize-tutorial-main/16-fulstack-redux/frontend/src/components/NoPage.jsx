function NoPage() {
  return (
    <>
      <div>NoPage</div>
    </>
  );
}

export default NoPage;
