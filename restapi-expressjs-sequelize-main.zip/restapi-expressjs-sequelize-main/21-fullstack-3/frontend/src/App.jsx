import RoutePage from "./auth/RoutePage.jsx";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <>
      <RoutePage />
    </>
  );
}

export default App;
