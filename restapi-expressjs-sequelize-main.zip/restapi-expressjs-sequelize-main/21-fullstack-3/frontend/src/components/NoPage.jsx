function NoPage() {
  return (
    <>
      <div
        className="d-flex justify-content-center align-items-center"
        style={{ height: "100vh" }}
      >
        <div>
          <h1>404 Page Not Found</h1>
        </div>
      </div>
    </>
  );
}

export default NoPage;
