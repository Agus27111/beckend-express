function Logout() {
  return <div>Logout</div>;
}

export default Logout;
