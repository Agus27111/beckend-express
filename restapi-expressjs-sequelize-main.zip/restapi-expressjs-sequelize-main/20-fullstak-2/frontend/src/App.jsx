import RoutePage from "./auth/RoutePage.jsx";

function App() {
  return (
    <>
      <RoutePage />
    </>
  );
}

export default App;
